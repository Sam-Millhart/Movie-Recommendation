import pandas as pd
import os
import csv
import tkinter as tk
from tkinter.scrolledtext import ScrolledText
from sklearn.feature_extraction.text import TfidfVectorizer
import matplotlib, numpy, sys
matplotlib.use('TkAgg')
from matplotlib.backends.backend_tkagg import (FigureCanvasTkAgg, NavigationToolbar2Tk)
from matplotlib.figure import Figure

class Lambda:
    pass

#create dict
dirname = os.path.dirname(__file__)
filename = os.path.join(dirname, 'tmdb_movies_data.csv')
with open(filename, encoding="utf-8") as movieDatabase:
    spamreader = csv.reader(movieDatabase)
    movieDatabaseDict = {}

    for spreadsheetHeaders in spamreader:
        movieId = spreadsheetHeaders[0]
        popularity = spreadsheetHeaders[1]
        budget = spreadsheetHeaders[2]
        revenue = spreadsheetHeaders[3]
        originalTitle = spreadsheetHeaders[4]
        movieCast = spreadsheetHeaders[5].replace('|', ', ')
        director = spreadsheetHeaders[6].replace('|', ', ')
        movieKeywords = spreadsheetHeaders[7].replace('|', ', ')
        movieOverview = spreadsheetHeaders[8]
        movieRuntime = spreadsheetHeaders[9]
        genres = spreadsheetHeaders[10].replace('|', ', ')
        productionCompany = spreadsheetHeaders[11].replace('|', ', ')
        releaseDate = spreadsheetHeaders[12]
        voteCount = spreadsheetHeaders[13]
        voteAverage = spreadsheetHeaders[14]
        releaseYear = spreadsheetHeaders[15]
        budgetAdj = spreadsheetHeaders[16]
        revenueAdj = spreadsheetHeaders[17]

        movieDatabaseDict[movieId] = spreadsheetHeaders[1:]
        movieDatabaseDict[movieId] = [popularity, budget, revenue, originalTitle, movieCast, director, movieKeywords,
                                      movieOverview, movieRuntime, genres, productionCompany, releaseDate, voteCount,
                                      voteAverage, releaseYear, budgetAdj, revenueAdj]


        value = [movieId, popularity, budget, revenue, originalTitle, movieCast,
                                      director, movieKeywords, movieOverview, movieRuntime, genres, productionCompany,
                                      releaseDate, voteCount, voteAverage, releaseYear, budgetAdj, revenueAdj]

    #creates dataframe
    movieDatebaseDF = pd.DataFrame(movieDatabaseDict).transpose()
    movieDatebaseDF.columns = movieDatebaseDF.iloc[0]
    movieDatebaseDF = movieDatebaseDF[1:]

    #Get counts for genres and ratings
    countsGenre = dict()
    for i in movieDatebaseDF.index:
        for g in movieDatebaseDF.loc[i, 'genres'].split(' '):
            if g not in countsGenre:
                countsGenre[g] = 1
            else:
                countsGenre[g] = countsGenre[g] + 1

    countsRatings = dict()
    for i in movieDatebaseDF.index:
        for g in movieDatebaseDF.loc[i, 'vote_average'].split(' '):
            if g not in countsRatings:
                countsRatings[g] = 1
            else:
                countsRatings[g] = countsRatings[g] + 1

    #Creating GUI
    root = tk.Tk()
    frame = tk.Frame(root)
    text = ScrolledText(root, state='disable')
    text.pack(fill='both', expand=True)

    frame = tk.Frame(text)
    text.window_create('1.0', window=frame)
    f = Figure(figsize=(5.5, 7), dpi=100)
    ax = f.add_subplot(111)

    dataGenre = (countsGenre.values())
    indGenre = countsGenre.keys()

    # the x locations for the groups
    width = .5
    for tick in ax.get_xticklabels():
        tick.set_rotation(90)

    rects1 = ax.bar(indGenre, dataGenre, width)

    frame1 = tk.Frame(text)
    text.window_create('1.0', window=frame1)
    f1 = Figure(figsize=(6, 7), dpi=100)
    ax = f1.add_subplot(111)

    dataRatings = (countsRatings.values())
    indRatings = countsRatings.keys()
    width = .5
    for tick in ax.get_xticklabels():
        tick.set_rotation(90)
    rects2 = ax.bar(indRatings, dataRatings, width)

    frame2 = tk.Frame(text)
    text.window_create('1.0', window=frame2)
    f2 = Figure(figsize=(6, 7), dpi=100)
    ax = f2.add_subplot(111)

    dataGenre = (countsGenre.values())
    indGenre = countsGenre.keys()
    width = .5
    for tick in ax.get_xticklabels():
        tick.set_rotation(90)
    rects3 = ax.scatter(indGenre, dataGenre)

    canvas = FigureCanvasTkAgg(f, master=root)
    canvas.get_tk_widget().place(relx=0.010, rely=0.100)
    toolbar = NavigationToolbar2Tk(canvas, root)
    toolbar.update()
    canvas._tkcanvas.place(relx=0.001, rely=0.100)

    canvas = FigureCanvasTkAgg(f1, master=root)
    canvas.get_tk_widget().place(relx=0.310, rely=0.100)
    toolbar = NavigationToolbar2Tk(canvas, root)
    toolbar.update()
    canvas._tkcanvas.place(relx=0.310, rely=0.100)

    canvas = FigureCanvasTkAgg(f2, master=root)
    canvas.get_tk_widget().place(relx=0.50, rely=0.100)
    toolbar = NavigationToolbar2Tk(canvas, root)
    toolbar.update()
    canvas._tkcanvas.place(relx=0.50, rely=0.100)

    tk.mainloop()

    #tfidfVectorizer creates matrix of data
    from sklearn.metrics.pairwise import cosine_similarity
    from sklearn.metrics.pairwise import linear_kernel
    import numpy

    # remove extra words ie "the" "an" "a"
    tfidf = TfidfVectorizer(stop_words='english')

    #creating movie x genre matrix
    tfidf_matrix = tfidf.fit_transform(movieDatebaseDF['genres'])

    tfidf.get_feature_names_out()

    #creating movie x movie matrix
    cosineSim = linear_kernel(tfidf_matrix, tfidf_matrix)

    cosineSim2 = cosine_similarity(tfidf_matrix, tfidf_matrix)

    movieDatebaseDFT = movieDatebaseDF.reset_index()

    def get_recommendations (getTitle, cosineSim=cosineSim2):
        if getTitle == 'original_title':
            getTitle = getTitle
        indices = pd.Series(movieDatebaseDFT.index, index=movieDatebaseDFT['original_title'])
        idx = indices[getTitle]

        #get the pairwise similarity scores of all movies with that movie
        simScores = list(enumerate(cosineSim[idx]))

        #Sort the movies based on similarity scores
        simScores = sorted(simScores, key=lambda x: x[1], reverse=True)
        simScores = simScores[1:11]

        #get the movie indices
        moviesIndices = [ind[0] for ind in simScores]
        movieRecommendations = movieDatebaseDFT['original_title'].iloc[moviesIndices]
        return movieRecommendations



    print("Since you watched Jurassic World you may like:")
    print(get_recommendations("Jurassic World", cosineSim2))

    print("Since you watched Inside Out you may like:")
    print(get_recommendations("Inside Out", cosineSim2))
